import React, { useState } from "react";

const tabStyle = {
  background: "#1e293b",
  padding: "1rem",
  color: "#fff",
  display: "flex",
  gap: "1rem",
  justifyContent: "center"
};

const tabBtn = (active) => ({
  padding: "0.5rem 1rem",
  background: active ? "#3b82f6" : "#334155",
  border: "none",
  borderRadius: "5px",
  color: "white",
  cursor: "pointer"
});

const card = {
  background: "white",
  borderRadius: "1rem",
  padding: "2rem",
  color: "black",
  boxShadow: "0 2px 10px rgba(0,0,0,0.2)",
  maxWidth: "800px",
  margin: "2rem auto"
};

function Tab1() {
  return (
    <div style={card}>
      <h2>資產分析</h2>
      <p>這裡會有收入支出輸入表單、資產配置圓餅圖與成長折線圖</p>
    </div>
  );
}

function Tab2() {
  return (
    <div style={card}>
      <h2>投資&理財</h2>
      <p>這裡會有投資標的輸入（複利計算）、報酬率選擇與總表格</p>
    </div>
  );
}

function Tab3() {
  return (
    <div style={card}>
      <h2>目標</h2>
      <p>這裡會有三個財務目標與進度條</p>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState(0);

  return (
    <div style={{ background: "#0f172a", color: "white", minHeight: "100vh" }}>
      <div style={{ textAlign: "center", paddingTop: "1rem" }}>
        <img src="/logo.png" alt="Finova Logo" style={{ width: 100 }} />
        <h1>歡迎使用 Finova 財務儀表板</h1>
      </div>

      <div style={tabStyle}>
        <button style={tabBtn(tab === 0)} onClick={() => setTab(0)}>資產分析</button>
        <button style={tabBtn(tab === 1)} onClick={() => setTab(1)}>投資&理財</button>
        <button style={tabBtn(tab === 2)} onClick={() => setTab(2)}>目標</button>
      </div>

      {tab === 0 && <Tab1 />}
      {tab === 1 && <Tab2 />}
      {tab === 2 && <Tab3 />}

      <footer style={{
        marginTop: "4rem",
        background: "linear-gradient(to right, #a2b6df, #7995e1)",
        padding: "2rem",
        textAlign: "center",
        color: "#333",
        fontSize: "0.9rem"
      }}>
        <h2 style={{ marginBottom: "1rem" }}>Finova Team 創新 x 獨特 x 成長</h2>
        <p>官方 LINE：@460cfyhl | <a href="#" style={{ color: "#1e40af" }}>加入我們</a></p>
        <p>2025 © Finova Team 版權所有 · 未經授權不得轉載</p>
      </footer>
    </div>
  );
}
